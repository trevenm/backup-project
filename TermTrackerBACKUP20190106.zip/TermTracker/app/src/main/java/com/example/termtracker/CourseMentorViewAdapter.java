package com.example.termtracker;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class CourseMentorViewAdapter extends RecyclerView.Adapter<CourseMentorViewAdapter.ViewHolder> {

    DBHelper myHelper;
    private ArrayList<Mentor> mentors;
    private Context mContext;

    public CourseMentorViewAdapter(ArrayList<Mentor> mentors, Context context) {
        this.mentors = mentors;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_checklist, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final Mentor mentor = mentors.get(position);
        holder.itemName.setText(mentor.getMentorName());
        holder.checkBox.setChecked(mentor.isForCourse());
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox myCheckBox= (CheckBox) v;

                if(myCheckBox.isChecked()) {
                    mentor.setForCourse(true);
                    Log.d("trev","course in Term");
                }
                else if(!myCheckBox.isChecked()) {
                    mentor.setForCourse(false);
                    Log.d("trev","course not in term");
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mentors.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemName;
        CheckBox checkBox;
        LinearLayout parentLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            checkBox = itemView.findViewById(R.id.checkBox);
            parentLayout = itemView.findViewById(R.id.parent_layout);
        }
    }


}
