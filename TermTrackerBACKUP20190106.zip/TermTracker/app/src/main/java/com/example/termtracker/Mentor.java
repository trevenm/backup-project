package com.example.termtracker;

public class Mentor {
    private String mentorName;
    private String phone;
    private String email;
    private boolean forCourse;

    public Mentor(String mentorName, String phone, String email, boolean forCourse) {
        this.mentorName = mentorName;
        this.phone = phone;
        this.email = email;
        this.forCourse = forCourse;
    }

    public String getMentorName() {
        return mentorName;
    }

    public void setMentorName(String mentorName) {
        this.mentorName = mentorName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isForCourse() {
        return forCourse;
    }

    public void setForCourse(boolean forCourse) {
        this.forCourse = forCourse;
    }
}
