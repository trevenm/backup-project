package com.example.termtracker;

public class Assessment {
    private String assessmentName;
    private String dueDate;
    private String type;
    private boolean inCourse;

    public Assessment(String assessmentName, String dueDate, String type, boolean inCourse) {
        this.assessmentName = assessmentName;
        this.dueDate = dueDate;
        this.type = type;
        this.inCourse = inCourse;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isInCourse() {
        return inCourse;
    }

    public void setInCourse(boolean inCourse) {
        this.inCourse = inCourse;
    }
}
