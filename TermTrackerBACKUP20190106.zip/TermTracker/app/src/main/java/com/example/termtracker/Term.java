package com.example.termtracker;

public class Term {
    private String termName;
    private String startDate;
    private String endDate;
    private Course[] courses;

    public Term(String termName, String startDate, String endDate, Course[] courses) {
        this.termName = termName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.courses = courses;
    }

    public String getTermName() {
        return termName;
    }

    public void setTermName(String termName) {
        this.termName = termName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Course[] getCourses() {
        return courses;
    }

    public void setCourses(Course[] courses) {
        this.courses = courses;
    }
}
