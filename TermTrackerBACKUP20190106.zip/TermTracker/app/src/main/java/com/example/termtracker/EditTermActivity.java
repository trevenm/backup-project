package com.example.termtracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class EditTermActivity extends AppCompatActivity {
    DBHelper myHelper;
    private ArrayList<Course> courses = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent myIntent = getIntent();
        final String term = myIntent.getStringExtra("term");

        setContentView(R.layout.activity_edit_term);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(EditTermActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();
        final EditText termNameField = findViewById(R.id.termNameField);
        final EditText startDateField = findViewById(R.id.startDateField);
        final EditText endDateField = findViewById(R.id.endDateField);
        final Button saveButton = findViewById(R.id.saveButton);
        final Button deleteButton = findViewById(R.id.deleteButton);


        String[] termColumns = {"termName", "startDate", "endDate"};
        Cursor cursor = db.query("terms", termColumns, "termName = '" + term + "'", null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String start = cursor.getString(1);
            String end = cursor.getString(2);
            termNameField.setText(name);
            startDateField.setText(start);
            endDateField.setText(end);
        }
        cursor.close();

        termNameField.setFocusable(false);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTerm(termNameField.getText().toString(), startDateField.getText().toString(), endDateField.getText().toString(), courses);
                Intent myIntent = new Intent(EditTermActivity.this, TermsActivity.class);
                startActivity(myIntent);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteTerm();;
                Intent myIntent = new Intent(EditTermActivity.this, TermsActivity.class);
                startActivity(myIntent);
            }
        });

        initRecyclerView();

    }

    private void initRecyclerView() {

        courses = getCourses();

        RecyclerView recyclerView = findViewById(R.id.recycler);
        EditTermViewAdapter adapter = new EditTermViewAdapter(courses, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    public void saveTerm(String termName, String startDate, String endDate, ArrayList<Course> courses) {

        myHelper.updateTermCourse(termName, courses);
        myHelper.updateTerm(termName, startDate, endDate);
    }

    public void deleteTerm(){
        Intent myIntent = getIntent();
        final String term = myIntent.getStringExtra("term");

        myHelper.deleteTerm(term);
        myHelper.deleteTermCourse(term,"termName");

    }

    public ArrayList<Course> getCourses() {

        Intent myIntent = getIntent();
        final String term = myIntent.getStringExtra("term");

        ArrayList<Course> queriedCourses = new ArrayList<>();
        SQLiteDatabase db = myHelper.getWritableDatabase();


        String[] columns = {"termCourse.courseName","courses.status","courses.startDate","courses.endDate","termCourse.inTerm"};
        Cursor cursor = db.query("termCourse, courses", columns, "termCourse.termName = '" + term + "' AND termCourse.courseName = courses.courseName",
                null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String status = cursor.getString(1);
            String start = cursor.getString(2);
            String end = cursor.getString(3);
            Boolean inTerm = cursor.getInt(4) == 1;
            queriedCourses.add(new Course(name, status, start, end, inTerm));
        }

        cursor.close();
        return queriedCourses;

    }
}
