package com.example.termtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void initTables() {
        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS terms " +
                "(termId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "termName varchar(100)," +
                "startDate date," +
                "endDate date)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS courses " +
                "(courseId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "courseName varchar(100)," +
                "status varchar(25)," +
                "startDate date," +
                "endDate date," +
                "notes TEXT)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS assessments " +
                "(assessmentId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "assessmentName varchar(100)," +
                "assessmentType varchar(50)," +
                "dueDate date)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS mentors " +
                "(mentorId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "mentorName varchar(100)," +
                "phone varchar(12)," +
                "email varchar(100))");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS termCourse " +
                "(courseTermId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "termName varchar(100)," +
                "courseName varchar(100)," +
                "inTerm boolean)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS courseAssessment " +
                "(courseAssessmentId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "courseName varchar(100)," +
                "assessmentName varchar(100)," +
                "inCourse boolean)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS courseMentor " +
                "(courseMentorId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "courseName varchar(100)," +
                "mentorName varchar(100)," +
                "forCourse boolean)");

    }

    public void insertRecord(String sqlStatement) {

        this.getWritableDatabase().execSQL(sqlStatement);

    }

    public long addTerm(String column1, String value1, String column2, String value2, String column3, String value3) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(column1, value1);
        values.put(column2, value2);
        values.put(column3, value3);

        return db.insert("terms", null, values);

    }

    public long addCourse(String courseName, String startDate, String endDate, String status, String notes) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("courseName", courseName);
        values.put("startDate", startDate);
        values.put("endDate", endDate);
        values.put("status",status);
        values.put("notes",notes);

        return db.insert("courses", null, values);

    }

    public void addAssessment(String assessmentName, String dueDate, String type){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("assessmentName",assessmentName);
        values.put("dueDate",dueDate);
        values.put("assessmentType",type);
        db.insert("assessments",null,values);

    }

    public long addMentor(String mentorName, String phone, String email) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("mentorName", mentorName);
        values.put("phone",phone);
        values.put("email",email);

        return db.insert("mentors", null, values);

    }

    public void addTermCourse(String courseName,String termName) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String[] termColumns = {"termId","termName"};
        Boolean inTerm = false;

        Cursor cursor = db.query("terms", termColumns, "termName = '" + termName + "'", null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(1);
            //int termId = cursor.getInt(0);
            //values.put("courseId",courseId);
            values.put("courseName", courseName);
            values.put("termName",name);
            //values.put("termId",termId);
            values.put("inTerm",inTerm);
            db.insert("termCourse", null, values);
            values.clear();
        }
        cursor.close();

    }

    public void addTermCourse(String termName, ArrayList<Course> courses){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int courseNum = 0;

        while (courseNum < courses.size()){
            final Course course = courses.get(courseNum);
            values.put("termName",termName);
            values.put("courseName",course.getCourseName());
            values.put("inTerm",course.isInTerm());
            db.insert("termCourse",null,values);
            values.clear();
            courseNum++;
        }

    }



    public void addCourseAssessment(String courseName, ArrayList<Assessment> assessments){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int assessmentNum = 0;

        while (assessmentNum < assessments.size()){
            final Assessment assessment = assessments.get(assessmentNum);
            values.put("courseName",courseName);
            values.put("assessmentName",assessment.getAssessmentName());
            values.put("inCourse",assessment.isInCourse());
            db.insert("courseAssessment",null,values);
            values.clear();
            assessmentNum++;
        }

    }

    public void addCourseMentor(String courseName, ArrayList<Mentor> mentors){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int mentorNum = 0;

        while (mentorNum < mentors.size()){
            final Mentor mentor = mentors.get(mentorNum);
            values.put("courseName",courseName);
            values.put("mentorName",mentor.getMentorName());
            values.put("forCourse",mentor.isForCourse());
            db.insert("courseMentor",null,values);
            values.clear();
            mentorNum++;
        }

    }
}
