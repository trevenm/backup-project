package com.example.termtracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class EditTermActivity extends AppCompatActivity {
    DBHelper myHelper;
    private ArrayList<Course> courses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_term);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(EditTermActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();

        final EditText termNameField = findViewById(R.id.termNameField);
        final EditText startDateField = findViewById(R.id.startDateField);
        final EditText endDateField = findViewById(R.id.endDateField);
        Button addTermButton = findViewById(R.id.addTermButton);

        addTermButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTerm(termNameField.getText().toString(),startDateField.getText().toString(),endDateField.getText().toString(), courses);
                Intent myIntent = new Intent(EditTermActivity.this, TermsActivity.class);
                startActivity(myIntent);
            }
        });

        initRecyclerView();

    }

    private void initRecyclerView() {

        courses = getCourses();

        RecyclerView recyclerView = findViewById(R.id.recycler);
        EditTermViewAdapter adapter = new EditTermViewAdapter(courses, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    public void addTerm(String termName, String startDate, String endDate, ArrayList<Course> courses) {

        myHelper.addTermCourse(termName,courses);
        myHelper.addTerm("termName",termName,"startDate",startDate,"endDate",endDate);
    }

    public ArrayList<Course> getCourses(){

        ArrayList<Course> queriedCourses = new ArrayList<>();

        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] columns = {"courseName","startDate","endDate","status"};
        Cursor cursor = db.query("courses", columns, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String start = cursor.getString(1);
            String end = cursor.getString(2);
            String status = cursor.getString(3);
            Boolean inTerm = false;
            queriedCourses.add(new Course(name,status,start,end,inTerm));
        }

        cursor.close();
        return queriedCourses;
    }
}
