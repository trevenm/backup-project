package com.example.termtracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TermsDetailActivity extends AppCompatActivity {
    DBHelper myHelper;
    private String name;
    private String start;
    private String end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TextView termNameField = findViewById(R.id.termNameField);
        TextView startDateField = findViewById(R.id.startDateField);
        TextView endDateField = findViewById(R.id.endDateField);
        Button deleteButton = findViewById(R.id.deleteButton);

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteTerm();
            }
        });

        Intent myIntent = getIntent();
        String term = myIntent.getStringExtra("term");

        myHelper = new DBHelper(TermsDetailActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] column = {"termName"};
        Cursor cursor = db.query("terms", null, "termName = '" + term + "'", null, null, null, null);
        while (cursor.moveToNext()) {
            name = cursor.getString(1);
            termNameField.setText(name);
            start = cursor.getString(2);
            startDateField.setText(start);
            end = cursor.getString(3);
            endDateField.setText(end);

            cursor.close();
        }
    }

    public int deleteTerm() {
        Intent myIntent = getIntent();
        String term = myIntent.getStringExtra("term");

        myHelper = new DBHelper(TermsDetailActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();

        myIntent = new Intent(TermsDetailActivity.this, TermsActivity.class);
        startActivity(myIntent);

        return db.delete("terms", "termName = '" + term + "'", null);
    }
}
