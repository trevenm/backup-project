package com.example.termtracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class EditAssessmentActivity extends AppCompatActivity {
    DBHelper myHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_assessment);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(EditAssessmentActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();

        final EditText assessmentNameField = findViewById(R.id.assessmentNameField);
        final EditText dueDateField = findViewById(R.id.dueDateField);
        final RadioGroup radioGroup = findViewById(R.id.typeRadioGroup);
        final RadioButton objRadio = findViewById(R.id.objectiveRadio);
        final RadioButton perfRadio = findViewById(R.id.performanceRadio);
        Button saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(radioId);

                saveAssessment(assessmentNameField.getText().toString(),dueDateField.getText().toString(),radioButton.getText().toString());
                Intent myIntent = new Intent(EditAssessmentActivity.this, AssessmentActivity.class);
                startActivity(myIntent);
            }
        });


    }


    public void saveAssessment(String assessmentName, String dueDate, String type) {

        myHelper.addAssessment(assessmentName,dueDate,type);

    }


}
