package com.example.termtracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class TermsActivity extends AppCompatActivity {
    DBHelper myHelper;
    private ArrayList<String> mTerms = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(TermsActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();
        myHelper.initTables();

        Button addTermButton = findViewById(R.id.addTermButton);
        addTermButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(TermsActivity.this, EditTermActivity.class);
                startActivity(myIntent);
            }
        });

        initRecyclerView();


    }

    private void initRecyclerView() {

        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] column = {"termName"};

        Cursor cursor = db.query("terms", column, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            mTerms.add(name);
        }
        cursor.close();

        RecyclerView recyclerView = findViewById(R.id.terms_recycler);
        TermsViewAdapter adapter = new TermsViewAdapter(mTerms, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    @Override
    protected void onPause() {
        super.onPause();
        myHelper.close();
        Toast.makeText(TermsActivity.this, myHelper.getDatabaseName() + " closed", Toast.LENGTH_SHORT).show();
    }

}
