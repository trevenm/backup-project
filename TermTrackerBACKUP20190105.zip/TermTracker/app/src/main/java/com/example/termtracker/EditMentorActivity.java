package com.example.termtracker;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class EditMentorActivity extends AppCompatActivity {
    DBHelper myHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_mentor);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(EditMentorActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();

        final EditText mentorNameField = findViewById(R.id.mentorNameField);
        final EditText phoneField = findViewById(R.id.phoneField);
        final EditText emailField = findViewById(R.id.emailField);
        Button saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMentor(mentorNameField.getText().toString(),phoneField.getText().toString(),emailField.getText().toString());
                Intent myIntent = new Intent(EditMentorActivity.this, MentorActivity.class);
                startActivity(myIntent);
            }
        });


    }


    public void saveMentor(String mentorName, String phone, String email) {

        myHelper.addMentor(mentorName,phone,email);

    }


}
