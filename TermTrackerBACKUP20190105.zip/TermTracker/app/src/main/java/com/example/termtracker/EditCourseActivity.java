package com.example.termtracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Calendar;

public class EditCourseActivity extends AppCompatActivity {
    DBHelper myHelper;
    private ArrayList<Assessment> assessments = new ArrayList<>();
    private ArrayList<Mentor> mentors = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(EditCourseActivity.this);
        final SQLiteDatabase db = myHelper.getWritableDatabase();

        final EditText courseNameField = findViewById(R.id.courseNameField);
        final EditText startDateField = findViewById(R.id.startDateField);
        final EditText endDateField = findViewById(R.id.endDateField);
        final EditText notesField = findViewById(R.id.notesField);
        final CheckBox notifyCheckBox = findViewById(R.id.notifyCheckBox);

        final Spinner statusSpinner = findViewById(R.id.statusSpinner);
        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this,R.array.courseStatus,android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(arrayAdapter);

        Button addCourseButton = findViewById(R.id.addCourseButton);
        addCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addCourse(courseNameField.getText().toString(), startDateField.getText().toString(),
                        endDateField.getText().toString(),statusSpinner.getSelectedItem().toString(),notesField.getText().toString());

                Intent myIntent = new Intent(EditCourseActivity.this, CoursesActivity.class);
                startActivity(myIntent);
            }
        });

        notifyCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(notifyCheckBox.isChecked()){
                    //notification
                    setNotification();
                    Log.d("trev","Notify checked");

                } else if (!notifyCheckBox.isChecked()){
                    //nothing
                    Log.d("trev","Notify unchecked");
                }
            }
        });

        initRecyclerViews();

    }

    private void initRecyclerViews() {

        assessments = getAssessments();
        mentors = getMentors();

        RecyclerView assessmentRecyclerView = findViewById(R.id.assessmentRecycler);
        CourseAssessmentViewAdapter assessAdapter = new CourseAssessmentViewAdapter(assessments, this);
        assessmentRecyclerView.setAdapter(assessAdapter);
        assessmentRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView mentorsRecyclerView = findViewById(R.id.mentorRecycler);
        CourseMentorViewAdapter mentorAdapter = new CourseMentorViewAdapter(mentors, this);
        mentorsRecyclerView.setAdapter(mentorAdapter);
        mentorsRecyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    public ArrayList<Assessment> getAssessments(){

        ArrayList<Assessment> queriedAssessments = new ArrayList<>();

        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] columns = {"assessmentName","dueDate","assessmentType"};
        Cursor cursor = db.query("assessments", columns, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String due = cursor.getString(1);
            String type = cursor.getString(2);
            Boolean inCourse = false;
            queriedAssessments.add(new Assessment(name,due,type,inCourse));
        }

        cursor.close();
        return queriedAssessments;
    }

    public ArrayList<Mentor> getMentors(){

        ArrayList<Mentor> queriedMentors = new ArrayList<>();

        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] columns = {"mentorName","phone","email"};
        Cursor cursor = db.query("mentors", columns, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String phone = cursor.getString(1);
            String email = cursor.getString(2);
            Boolean forCourse = false;
            queriedMentors.add(new Mentor(name,phone,email,forCourse));
        }

        cursor.close();
        return queriedMentors;
    }

    public void addCourse(String courseName, String startDate, String endDate, String status, String notes) {

        myHelper.addCourse(courseName, startDate,endDate,status, notes);
        myHelper.addCourseAssessment(courseName,assessments);
        myHelper.addCourseMentor(courseName,mentors);

        SQLiteDatabase db = myHelper.getWritableDatabase();
        String[] column = {"termName"};
        Cursor cursor = db.query("terms",column, null, null, "termName", null, null);
        while (cursor.moveToNext()) {
            String termName = cursor.getString(0);
            myHelper.addTermCourse(courseName,termName);
        }
        cursor.close();
    }

    public void setNotification(){
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent("termtracker.action.DISPLAY_NOTIFICATION");
        PendingIntent broadcast = PendingIntent.getBroadcast(EditCourseActivity.this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.SECOND, 10);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), broadcast);
    }
}
