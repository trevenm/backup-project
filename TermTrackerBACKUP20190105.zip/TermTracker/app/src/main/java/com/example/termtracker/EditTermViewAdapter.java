package com.example.termtracker;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class EditTermViewAdapter extends RecyclerView.Adapter<EditTermViewAdapter.ViewHolder> {

    private static final String TAG = "EditTermViewAdapter";
    DBHelper myHelper;
    private ArrayList<Course> courses;
    private Context mContext;

    public EditTermViewAdapter(ArrayList<Course> courses, Context context) {
        this.courses = courses;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_checklist, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder called.");

        final Course course = courses.get(position);
        holder.itemName.setText(course.getCourseName());
        holder.checkBox.setChecked(course.isInTerm());
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox myCheckBox= (CheckBox) v;

                if(myCheckBox.isChecked()) {
                    course.setInTerm(true);
                    Log.d("trev","course in Term");
                }
                else if(!myCheckBox.isChecked()) {
                    course.setInTerm(false);
                    Log.d("trev","course not in term");
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return courses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemName;
        CheckBox checkBox;
        LinearLayout parentLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            checkBox = itemView.findViewById(R.id.checkBox);
            parentLayout = itemView.findViewById(R.id.parent_layout);
        }
    }


}
