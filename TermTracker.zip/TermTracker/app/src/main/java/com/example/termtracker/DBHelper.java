package com.example.termtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void initTables(){
        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS terms " +
                "(termId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "termName varchar(100)," +
                "startDate date," +
                "endDate date)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS courses " +
                "(courseId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "courseName varchar(100)," +
                "status varchar(25)," +
                "startDate date," +
                "endDate date," +
                "termId int)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS assessments " +
                "(assessmentId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "courseId int," +
                "assessmentName varchar(100)," +
                "note text," +
                "dueDate date)");

        this.getWritableDatabase().execSQL("CREATE TABLE IF NOT EXISTS mentors " +
                "(mentorId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "mentorName varchar(100)," +
                "phone varchar(15)," +
                "email varchar(100))");

    }

    public void insertRecord(String sqlStatement){

        this.getWritableDatabase().execSQL(sqlStatement);

    }

    public long addRecord(String tableName, String nameKey, String nameValue, String nameKey1, String nameValue1, String nameKey2, String nameValue2){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(nameKey,nameValue);
        values.put(nameKey1,nameValue1);
        values.put(nameKey2,nameValue2);

        return db.insert(tableName,null,values);

    }

}
