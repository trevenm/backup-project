package com.example.termtracker;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddCourseActivity extends AppCompatActivity {
    DBHelper myHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myHelper = new DBHelper(AddCourseActivity.this);
        SQLiteDatabase db = myHelper.getWritableDatabase();

        final EditText courseNameField = findViewById(R.id.courseNameField);
        final EditText startDateField = findViewById(R.id.startDateField);
        final EditText endDateField = findViewById(R.id.endDateField);
        Button addTermButton = findViewById(R.id.addCourseButton);

        addTermButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCourse(courseNameField.getText().toString(),startDateField.getText().toString(),endDateField.getText().toString());
                Intent myIntent = new Intent(AddCourseActivity.this, CoursesActivity.class);
                startActivity(myIntent);
            }
        });

    }

    public void addCourse(String termName, String startDate, String endDate) {

        myHelper.addRecord("courses","courseName",termName,"startDate",startDate,"endDate",endDate);

    }
}
